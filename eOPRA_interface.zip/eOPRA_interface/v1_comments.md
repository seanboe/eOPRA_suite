# Issues / fixes necessary

### 9/21:
- Forgot to select no part number on the board 
- mounting holes not aligned (off by about 0.5mm)


### 9/30 - After manufacturing
- Decoder doesn't provide all off option - there is always a port which is open
  - Probably add a mosfet in series with external switch